package io.github.LostMyCodes.box2dscene2dtest;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.ScreenUtils;

/** {@link com.badlogic.gdx.ApplicationListener} implementation shared by all platforms. */
public class box2dscene2dtest extends Game {
	// constructor and format for main class inspired from https://www.gamedevelopment.blog/full-libgdx-game-tutorial-project-setup/
   private LoadingScreen loadingScreen;
   private PreferencesScreen preferencesScreen;
   private MenuScreen menuScreen;
   private MainScreen mainScreen;
   private EndScreen endScreen;
   
   public final static int MENU = 0;
   public final static int PREFERENCES = 1;
   public final static int APPLICATION = 2;
   public final static int ENDGAME = 3;
@Override
public void create() {
	// TODO Auto-generated method stub
	menuScreen = new MenuScreen(this);
	setScreen(menuScreen);
}

@Override
public void render() {
	super.render();
}
 

public void changeScreen(int screen) {
	switch(screen) {
	case MENU:
		if(menuScreen == null) {
			menuScreen = new MenuScreen(this);
		}
          this.setScreen(menuScreen);
	case PREFERENCES:
		if(preferencesScreen == null) {
			preferencesScreen = new PreferencesScreen(this);
		}
		this.setScreen(preferencesScreen);
	case APPLICATION:
		if(mainScreen == null) {
			mainScreen = new MainScreen(this);
		}
		this.setScreen(mainScreen);
	case ENDGAME:
		if(endScreen == null) {
			endScreen = new EndScreen(this);
		}
		this.setScreen(endScreen);
	}

}

}
