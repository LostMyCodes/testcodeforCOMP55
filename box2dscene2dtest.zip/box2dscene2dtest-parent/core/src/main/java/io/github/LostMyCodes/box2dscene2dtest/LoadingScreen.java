package io.github.LostMyCodes.box2dscene2dtest;

import com.badlogic.gdx.Screen;

public class LoadingScreen implements Screen {

	private box2dscene2dtest parent;
	
	public LoadingScreen(box2dscene2dtest box2d) {
		parent = box2d;
	}
	
	@Override
	public void show() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void render(float delta) {
		// TODO Auto-generated method stub
		parent.changeScreen(box2dscene2dtest.MENU);
		
	}

	@Override
	public void resize(int width, int height) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void resume() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void hide() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void dispose() {
		// TODO Auto-generated method stub
		
	}

}
